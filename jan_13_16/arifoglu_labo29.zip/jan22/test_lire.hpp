#ifndef TEST_LIRE_HPP
#define TEST_LIRE_HPP

#include <string>

void testLireFichier(const std::string& filePath);

#endif 




