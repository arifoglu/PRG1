#ifndef SETBASE_HPP
#define SETBASE_HPP

#include <cstddef> 

class Setbase {
public:
    static int base_affichage;
    static int set_base(size_t base);
};

#endif
