#ifndef TEST_RESOUDRE_HPP
#define TEST_RESOUDRE_HPP

#include <string>

void testResoudre(const std::string& filePath);

#endif 
